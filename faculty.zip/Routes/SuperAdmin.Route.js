import express from 'express';

import jwt from 'jsonwebtoken';

const router = express.Router();
router.get("/login",async (req, res) => {
    res.render("superAdmin/login");
})
router.use((req, res, next) => {
    if (req.cookies.token) {
        try {
            const user = jwt.verify(req.cookies.adminToken, process.env.JWT_SECRET);
            req.user = user;
            console.log('Decoded JWT:', user); // Log the decoded JWT payload
            console.log('User ID:', user.user_id); // Log the user ID specifically
            res.locals.loggedIn = user.loggedIn; // Set a local variable
        } catch (err) {
            console.error('JWT verification error:', err);
            res.clearCookie('token');
            res.locals.loggedIn = false; // Set a local variable
        }
    } else {
        res.locals.loggedIn = false; // Set a local variable
    }
    next();
});

router.post("/login", async (req, res) => {
    const { username, password } = req.body;
    console.log('username:', username);
    console.log('password:', password);
    // Check if the username and password match the expected values
    if (username === "superAdmin" && password === "superAdmin") {
        // Define the payload for the JWT
        const payload = {
            user_id: username, // This should be replaced with the actual user ID
            role: 'superAdmin' // This should be replaced with the actual user role
        };

        try {
            // Sign the JWT and set it as a cookie
            const token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '2h' });
            res.cookie('adminToken', token, { httpOnly: true });

            // Redirect the user to the dashboard
            res.redirect('/superAdmin/dashboard');
        } catch (err) {
            console.error('JWT signing error:', err);
            res.status(500).send('Server error');
        }
    } else {
        // If the username and password do not match the expected values, send an error message
        res.status(401).send('Invalid username or password');
    }
});




router.get("/dashboard",async (req, res) => {
    res.render("superAdmin/dashboard");
})



export default router;