import express from 'express';
import jwt from 'jsonwebtoken';

import facultyDb from '../faculty.db.js';
import { authorizeRole, jwtMiddleware } from '../service.js';
const router = express.Router();