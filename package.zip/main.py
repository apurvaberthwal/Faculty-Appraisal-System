"""
# Define three variables a, b, and c
a=1000
b=2000
c=3000

# Print the memory address of each variable
print (id(a),id(b),id(c))

# Import the ctypes and sys modules
import ctypes
import sys

# Get the address of the ctypes.py_object instance of a
address=ctypes.addressof(ctypes.py_object(a))
print (address)

# Get the address of the ctypes.py_object instances of b and c
print (ctypes.addressof(ctypes.py_object(b)))
print (ctypes.addressof(ctypes.py_object(c)))

# Print the size of each variable
print("size")
print(sys.getsizeof(a))
print(sys.getsizeof(b))
print(sys.getsizeof(c))

# Define three new variables a, b, and c
print("afy")
a=10
b=12
c=13

# Create ctypes.py_object instances of each variable
a_obj = ctypes.py_object(a)
b_obj = ctypes.py_object(b)
c_obj = ctypes.py_object(c)

# Get the address of each ctypes.py_object instance
print (ctypes.addressof(a_obj))
print (ctypes.addressof(b_obj))
print (ctypes.addressof(c_obj))

# Print the size of each new variable
print("size")
print(sys.getsizeof(a))
print(sys.getsizeof(b))
print(sys.getsizeof(c))
"""
#Single line comment Strings "AAA"/"""AAA"""
"""hello c"""
print("""AAA""")
"""
Data  types :
    1.Scalar : int ,float,object
    2. Sequence : list,string,tuple
    3. Mapping : dict,set,frozenset(immutable set)
    4. Boolean : True,False

Mutable : Values can be modified eg list,dict,set
Immutable : Values cannot be modified eg int,float,tuple,string,frozenset

Integer can be binary,octal,hexadecimal values eg 
Binary: 0b1010
Octal: 0o12
Hexadecimal: 0x12

"""

"""
oct=0o12
print("aa" ,oct)
hex=0x12
print(hex)
bin=0b1010
print(bin)
x="12"
print (type(x))
print (type(int(x)))
x=11
y=5
print(x**y)
print(x//y)
#complex numbers
c1=2+4j
c2=3+2j
print(c1+c2)
print(c1-c2)
print(c1*c2)
print(c1/c2)


String

"""

"""
AUG 2 2024
Python String supports reverse indexing 
"""
"""
greet = "Hello"
print(greet[-5])
print(greet[-4])
print(greet[-3])
print(greet[-2])
print(greet[-1])
print(greet[0])

Escape characters : \n,\t,\r,\b,\f,\',\"

str = "Hello \fWorld python"
print(str)
"""
#Operating in String: Concatenation,Repetition,Slicing 
#Operators Precedence : **,*,/,//,%,+,-

# String Methods : Captalize,casefold,center,count,encode,endswith,expandtabs,find,index,isalnum,isalpha,isascii,isdecimal
"""
a="helllo world python"
b=a.capitalize()
print(a)
print(b)

print(a.endswith("o"))
print(a.endswith("l",2,4)) #start,end index of string
# endwith with tuple
print(a.endswith(("BEN","o","hell")))
print(a.endswith(("BEN","o","hell"),8,9))
"""

#List : Mutable,Ordered,Allows duplicate values [1,"hello",2.3]
#List Methods : append,clear,copy(shallow),count,extend,index,insert,pop,remove,reverse,sort
"""
l1=[1,2,"Hellpworl",4.7,5]
print(l1)
l2=[22,12,"peter","griffin"]
print(l2)
print(type(l1))
l3=[l1,l2] #List of list items(nested list)
print(l3)
print(l3[1][2]) #Accessing nested list
print(type)
l3.remove(l3[1]) #
l4=l1+l2 #Concatenation of list
print(l4)

#del vs Pop : del removes the element from the list and pop returns the element from the list, Del is statement and Pop is  method


#statements in python is a single line of code that performs a specific task eg conditional statements,looping statements,control statements

#methods in python are functions that are associated with an object eg append() method is associated with list object z

#shallow copy vs deep copy : shallow copy is a copy of the object but the reference is copied and deep copy is a copy of the object and the reference is also copied
# shallow copy : copy.copy() , deep copy : copy.deepcopy()
#acutal and formal arguments : actual arguments are the arguments that are passed to the function and formal arguments are the arguments that are defined in the function 

l1=[1,2,3,4,5]
l2=l1.copy()
l1[0]=10
print(l1)
print(l2)
# NumPY 02/09/24
import numpy as np
a=np.array(l1)
print(a)

import array as ar
l=list(range(10))
a=ar.array("i",l)
print(a)
output: array('i', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
"""

########################  03/09/24 NUMPY ##################################
import numpy as np
list1=[1,True,"list1",1.0]
types = [type(a) for a in list1]
print(types)


arr=np.zeros((2,4),dtype=int) # array of 0 with 2 rows and 4 columns 
print(" array of 0 with 2 rows and 4 columns ")
print(arr)
arr=np.ones((2,4),dtype=int) # array of 1 with 2 rows and 4 columns
print(" array of 1 with 2 rows and 4 columns ")

print(arr)
arr=np.full((2,4),5) # array of 5 with 2 rows and 4 columns
print(" array of 5 with 2 rows and 4 columns ")

print(arr)
arr=np.eye(4) # array of 1 with 4 rows and 4 columns with diagonal 1 and rest 0
print(" IDENTIY MATRIX  OF 4X4 array")
print(arr)
arr=np.arange(0,20,2) # array of 0 to 20 with step 2
print(" array of 0 to 20 with step 2 ")
print(arr)


arr=np.linspace(0,20,5) # array of 0 to 20 with 5 elements
print(" array of 0 to 20 with 5 elements ")
print(arr)

arr=np.random.random((2,2)) # array of random numbers with 2 rows and 2 columns
print(" array of random numbers with 2 rows and 2 columns ")
print(arr)

arr=np.random.randint(10,size=5) # array of random numbers with 5 elements
print(" array of random numbers with 5 elements ")
print(arr)

arr = np.random.randint(10,size=(1,3,4)) # array of random numbers between 0 to 10 with 4 rows and 2 columns and 3 depth
print(" array of random numbers between 0 to 10 with 4 rows and 2 columns and 3 depth ")
print(arr)

arr=np.random.randint(0,10,(4,2)) # array of random numbers between 0 to 10 with 2 rows and 2 columns
print(" array of random numbers between 0 to 10 with 2 rows and 2 columns ")
print(arr)

#numpy array manipulation 

